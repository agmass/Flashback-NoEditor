package com.moulberry.flashback;

import net.minecraft.client.gui.components.toasts.SystemToast;

public class FlashbackSystemToasts {

    public static final SystemToast.SystemToastId RECORDING_TOAST = new SystemToast.SystemToastId();

}
