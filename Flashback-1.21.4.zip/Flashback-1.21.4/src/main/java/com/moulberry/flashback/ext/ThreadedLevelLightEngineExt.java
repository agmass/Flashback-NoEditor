package com.moulberry.flashback.ext;

public interface ThreadedLevelLightEngineExt {

    void flashback$submitPost(int x, int z, Runnable runnable);

}
