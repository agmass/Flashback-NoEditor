package com.moulberry.flashback.combo_options;

public interface ComboOption {

    String text();

}