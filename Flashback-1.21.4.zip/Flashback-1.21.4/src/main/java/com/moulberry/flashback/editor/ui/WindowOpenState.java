package com.moulberry.flashback.editor.ui;

public enum WindowOpenState {

    UNKNOWN,
    OPEN,
    CLOSED

}
