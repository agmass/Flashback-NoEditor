package com.moulberry.flashback.ext;

public interface OptionsExt {

    int flashback$getOriginalFov();

}
