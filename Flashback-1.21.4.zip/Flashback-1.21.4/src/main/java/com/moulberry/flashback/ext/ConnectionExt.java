package com.moulberry.flashback.ext;

public interface ConnectionExt {

    void flashback$setFilterUnnecessaryPackets();

}
