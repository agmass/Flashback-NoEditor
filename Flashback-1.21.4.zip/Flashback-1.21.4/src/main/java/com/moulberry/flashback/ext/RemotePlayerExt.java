package com.moulberry.flashback.ext;

public interface RemotePlayerExt {

    float flashback$getXBob(float partialTick);
    float flashback$getYBob(float partialTick);

}
