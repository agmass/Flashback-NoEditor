package com.moulberry.flashback.ext;

public interface ServerTickRateManagerExt {

    void flashback$setSuppressClientUpdates(boolean suppress);

}
